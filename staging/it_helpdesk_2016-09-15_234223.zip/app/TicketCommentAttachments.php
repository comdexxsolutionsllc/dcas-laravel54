<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TicketCommentAttachments extends Model {

	protected $table = 'ticket_comment_attachments';
	public $timestamps = true;

}