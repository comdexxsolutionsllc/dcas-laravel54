<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MachineNoteAttachments extends Model {

	protected $table = 'machine_note_attachments';
	public $timestamps = true;

}