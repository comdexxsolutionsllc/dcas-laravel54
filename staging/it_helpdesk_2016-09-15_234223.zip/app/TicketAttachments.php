<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TicketAttachments extends Model {

	protected $table = 'ticket_attachments';
	public $timestamps = true;

}